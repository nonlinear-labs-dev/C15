/******************************************************************************/
/** @file		nl_tcd_iir.h
    @date		2020-01-14
    @version	0
    @author		KSTR
    @brief		simple IIR lowpass
    @ingroup	nl_tcd_modules
*******************************************************************************/

#ifndef NL_TCD_IIR_H_
#define NL_TCD_IIR_H_

#endif
//EOF
