/******************************************************************************/
/** @file		nl_tcd_iir.h
    @date		2020-01-14
    @version	0
    @author		KSTR
    @brief		simple IIR lowpass
    @ingroup	nl_tcd_modules
*******************************************************************************/

#include "nl_tcd_iir.h"

// EOF
